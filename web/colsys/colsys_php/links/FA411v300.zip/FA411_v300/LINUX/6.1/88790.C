/* 88790.c: The network driver code is based on 8390.c      */
/* 8390.c: A general NS8390 ethernet driver core for linux. */
/*
	Written 1992-94 by Donald Becker.

	Copyright 1993 United States Government as represented by the
	Director, National Security Agency.

	This software may be used and distributed according to the terms
	of the GNU Public License, incorporated herein by reference.

	The author may be reached as becker@CESDIS.gsfc.nasa.gov, or C/O
	Center of Excellence in Space Data and Information Sciences
	   Code 930.5, Goddard Space Flight Center, Greenbelt MD 20771

  This is the chip-specific code for many 8390-based ethernet adaptors.
  This is not a complete driver, it must be combined with board-specific
  code such as ne.c, wd.c, 3c503.c, etc.

  Seeing how at least eight drivers use this code, (not counting the
  PCMCIA ones either) it is easy to break some card by what seems like
  a simple innocent change. Please contact me or Donald if you think
  you have found something that needs changing. -- PG


  Changelog:

  Paul Gortmaker	: remove set_bit lock, other cleanups.
  Paul Gortmaker	: add ei_get_8390_hdr() so we can pass skb's to
			  ei_block_input() for eth_io_copy_and_sum().
  Paul Gortmaker	: exchange static int ei_pingpong for a #define,
			  also add better Tx error handling.
  Paul Gortmaker	: rewrite Rx overrun handling as per NS specs.
  Alexey Kuznetsov	: use the 8390's six bit hash multicast filter.
  Paul Gortmaker	: tweak ANK's above multicast changes a bit.
  Paul Gortmaker	: update packet statistics for v2.1.x
  Alan Cox		: support arbitary stupid port mappings on the
  			  68K Macintosh. Support >16bit I/O spaces
  Paul Gortmaker	: add kmod support for auto-loading of the 8390
			  module by all drivers that require it.
  Alan Cox		: Spinlocking work, added 'BUG_83C690'

  Sources:
  The National Semiconductor LAN Databook, and the 3Com 3c503 databook.

  */

static const char *version =
    "88790.c: v1.10 2001/04/11\n";

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/ptrace.h>
#include <linux/string.h>
#include <asm/system.h>
#include <asm/uaccess.h>
#include <asm/bitops.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/fcntl.h>
#include <linux/in.h>
#include <linux/interrupt.h>
#include <linux/init.h>

#include <linux/netdevice.h>
#include <linux/etherdevice.h>

#define NS8390_CORE
#include "88790.h"

#define BUG_83C690

/* These are the operational function interfaces to board-specific
   routines.
	void reset_8390(struct device *dev)
		Resets the board associated with DEV, including a hardware reset of
		the 8390.  This is only called when there is a transmit timeout, and
		it is always followed by 8390_init().
	void block_output(struct device *dev, int count, const unsigned char *buf,
					  int start_page)
		Write the COUNT bytes of BUF to the packet buffer at START_PAGE.  The
		"page" value uses the 8390's 256-byte pages.
	void get_8390_hdr(struct device *dev, struct e8390_hdr *hdr, int ring_page)
		Read the 4 byte, page aligned 8390 header. *If* there is a
		subsequent read, it will be of the rest of the packet.
	void block_input(struct device *dev, int count, struct sk_buff *skb, int ring_offset)
		Read COUNT bytes from the packet buffer into the skb data area. Start
		reading from RING_OFFSET, the address as the 8390 sees it.  This will always
		follow the read of the 8390 header.
*/
#define ei_reset_8390 (ei_local->reset_8390)
#define ei_block_output (ei_local->block_output)
#define ei_block_input (ei_local->block_input)
#define ei_get_8390_hdr (ei_local->get_8390_hdr)

/* use 0 for production, 1 for verification, >2 for debug */
#ifndef ei_debug
int ei_debug = 1;
#endif

/* Index to functions. */
static void ei_tx_intr(struct device *dev);
static void ei_tx_err(struct device *dev);
static void ei_receive(struct device *dev);
static void ei_rx_overrun(struct device *dev);

/* Routines generic to NS8390-based boards. */
static void NS8390_trigger_send(struct device *dev, unsigned int length,
								int start_page);
static void set_multicast_list(struct device *dev);
static void do_set_multicast_list(struct device *dev);


/* Declare Mii functions */
typedef unsigned long ULONG, *PULONG;
typedef unsigned short USHORT, *PUSHORT;
typedef unsigned char UCHAR, *PUCHAR;
typedef int INT, *PINT;
#define IN
#define OUT
#define AX_TRUE 1
#define AX_FALSE 0
static void
inb_px(long port, unsigned char *value);
static void
A19xWriteMii(
		IN struct device *dev,
		IN ULONG		ulData,
		IN USHORT		uDataSize
		);
static INT
MiiReadRegister(
		IN struct device *dev,
		IN USHORT		uPhyAddr,
		IN USHORT		uRegNum,
		OUT PUSHORT		puRegData
		);
static void
MiiWriteRegister(
		IN struct device *dev,
		IN USHORT		uPhyAddr,
		IN USHORT		uRegNum,
		IN USHORT		uRegData
		);
static INT
AXSearchPhy(
	IN struct device *dev
	);
static void
AXInitPhy(
	IN struct device *dev
	 );
static INT
MediaModeChanged(
    IN struct device *dev
    );
static INT
AXGetPhyCapability(
    IN struct device *dev
    );





/*
 *	SMP and the 8390 setup.
 *
 *	The 8390 isnt exactly designed to be multithreaded on RX/TX. There is
 *	a page register that controls bank and packet buffer access. We guard
 *	this with ei_local->page_lock. Nobody should assume or set the page other
 *	than zero when the lock is not held. Lock holders must restore page 0
 *	before unlocking. Even pure readers must take the lock to protect in
 *	page 0.
 *
 *	To make life difficult the chip can also be very slow. We therefore can't
 *	just use spinlocks. For the longer lockups we disable the irq the device
 *	sits on and hold the lock. We must hold the lock because there is a dual
 *	processor case other than interrupts (get stats/set multicast list in
 *	parallel with each other and transmit).
 *
 *	Note: in theory we can just disable the irq on the card _but_ there is
 *	a latency on SMP irq delivery. So we can easily go "disable irq" "sync irqs"
 *	enter lock, take the queued irq. So we waddle instead of flying.
 *
 *	Finally by special arrangement for the purpose of being generally
 *	annoying the transmit function is called bh atomic. That places
 *	restrictions on the user context callers as disable_irq won't save
 *	them.
 */



/* Open/initialize the board.  This routine goes all-out, setting everything
   up anew at each open, even though many of these registers should only
   need to be set once at boot.
   */
int ei_open(struct device *dev)
{
	unsigned long flags;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;

	/* This can't happen unless somebody forgot to call ethdev_init(). */
	if (ei_local == NULL)
	{
		printk(KERN_NOTICE "ei_open fial\n");
		printk(KERN_EMERG "%s: ei_open passed a non-existent device!\n", dev->name);
		return -ENXIO;
	}

	/*
	 *	Grab the page lock so we own the register set, then call
	 *	the init function.
	 */

  	spin_lock_irqsave(&ei_local->page_lock, flags);

    AXSearchPhy(dev);
    ///
    // PHY Connection Type Setup
    ///
    AXInitPhy(dev);

//Angus Add 1999/11/9
	ei_local->fgMediaLinkFail = AX_TRUE;

    AXGetPhyCapability(dev);


	NS8390_init(dev, 1);

	/* Set the flag before we drop the lock, That way the IRQ arrives
	   after its set and we get no silly warnings */
	printk(KERN_INFO "ei_open set dev->start=1 \n");
	dev->start = 1;
   	spin_unlock_irqrestore(&ei_local->page_lock, flags);
	ei_local->irqlock = 0;
	return 0;
}

/* Opposite of above. Only used when "ifconfig <devname> down" is done. */
int ei_close(struct device *dev)
{
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	unsigned long flags;

	/*
	 *	Hold the page lock during close
	 */

      	spin_lock_irqsave(&ei_local->page_lock, flags);
	NS8390_init(dev, 0);
      	spin_unlock_irqrestore(&ei_local->page_lock, flags);
	dev->start = 0;
	return 0;
}

static int ei_start_xmit(struct sk_buff *skb, struct device *dev)
{
	long e8390_base = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	int length, send_length, output_page;
	unsigned long flags;

	/*
	 *  We normally shouldn't be called if dev->tbusy is set, but the
	 *  existing code does anyway. If it has been too long since the
	 *  last Tx, we assume the board has died and kick it. We are
	 *  bh_atomic here.
	 */

	if (dev->tbusy)
	{	/* Do timeouts, just like the 8003 driver. */
		int txsr;
		int isr;
		int tickssofar = jiffies - dev->trans_start;

		/*
		 *	Need the page lock. Now see what went wrong. This bit is
		 *	fast.
		 */

		spin_lock_irqsave(&ei_local->page_lock, flags);
		txsr = inb(e8390_base+EN0_TSR);
		if (tickssofar < TX_TIMEOUT ||	(tickssofar < (TX_TIMEOUT+5) && ! (txsr & ENTSR_PTX)))
		{
			spin_unlock_irqrestore(&ei_local->page_lock, flags);
			return 1;
		}

		ei_local->stat.tx_errors++;
		isr = inb(e8390_base+EN0_ISR);
		if (dev->start == 0)
		{
			spin_unlock_irqrestore(&ei_local->page_lock, flags);
			printk(KERN_WARNING "%s: xmit on stopped card\n", dev->name);
			return 1;
		}

		/*
		 * Note that if the Tx posted a TX_ERR interrupt, then the
		 * error will have been handled from the interrupt handler
		 * and not here. Error statistics are handled there as well.
		 */

		printk(KERN_DEBUG "%s: Tx timed out, %s TSR=%#2x, ISR=%#2x, t=%d.\n",
			dev->name, (txsr & ENTSR_ABT) ? "excess collisions." :
			(isr) ? "lost interrupt?" : "cable problem?", txsr, isr, tickssofar);

		if (!isr && !ei_local->stat.tx_packets)
		{
			/* The 8390 probably hasn't gotten on the cable yet. */
			ei_local->interface_num ^= 1;   /* Try a different xcvr.  */
		}

		/*
		 *	Play shuffle the locks, a reset on some chips takes a few
		 *	mS. We very rarely hit this point.
		 */

		spin_unlock_irqrestore(&ei_local->page_lock, flags);

		/* Ugly but a reset can be slow, yet must be protected */

		disable_irq_nosync(dev->irq);
		spin_lock(&ei_local->page_lock);

		/* Try to restart the card.  Perhaps the user has fixed something. */
		ei_reset_8390(dev);
		NS8390_init(dev, 1);

		spin_unlock(&ei_local->page_lock);
		enable_irq(dev->irq);
		dev->trans_start = jiffies;
	}

	length = skb->len;

	/* Mask interrupts from the ethercard.
	   SMP: We have to grab the lock here otherwise the IRQ handler
	   on another CPU can flip window and race the IRQ mask set. We end
	   up trashing the mcast filter not disabling irqs if we dont lock */

	spin_lock_irqsave(&ei_local->page_lock, flags);
	outb_p(0x00, e8390_base + EN0_IMR);
	spin_unlock_irqrestore(&ei_local->page_lock, flags);


	/*
	 *	Slow phase with lock held.
	 */

	disable_irq_nosync(dev->irq);

	spin_lock(&ei_local->page_lock);

	if (dev->interrupt)
	{
		printk(KERN_WARNING "%s: Tx request while isr active.\n",dev->name);
		outb_p(ENISR_ALL, e8390_base + EN0_IMR);
		spin_unlock(&ei_local->page_lock);
		enable_irq(dev->irq);
		ei_local->stat.tx_errors++;
		dev_kfree_skb(skb);
		return 0;
	}
	ei_local->irqlock = 1;

	send_length = ETH_ZLEN < length ? length : ETH_ZLEN;

#ifdef EI_PINGPONG

	/*
	 * We have two Tx slots available for use. Find the first free
	 * slot, and then perform some sanity checks. With two Tx bufs,
	 * you get very close to transmitting back-to-back packets. With
	 * only one Tx buf, the transmitter sits idle while you reload the
	 * card, leaving a substantial gap between each transmitted packet.
	 */

	if (ei_local->tx1 == 0)
	{
		output_page = ei_local->tx_start_page;
		ei_local->tx1 = send_length;
		if (ei_debug  &&  ei_local->tx2 > 0)
			printk(KERN_DEBUG "%s: idle transmitter tx2=%d, lasttx=%d, txing=%d.\n",
				dev->name, ei_local->tx2, ei_local->lasttx, ei_local->txing);
	}
	else if (ei_local->tx2 == 0)
	{
		output_page = ei_local->tx_start_page + TX_1X_PAGES;
		ei_local->tx2 = send_length;
		if (ei_debug  &&  ei_local->tx1 > 0)
			printk(KERN_DEBUG "%s: idle transmitter, tx1=%d, lasttx=%d, txing=%d.\n",
				dev->name, ei_local->tx1, ei_local->lasttx, ei_local->txing);
	}
	else
	{	/* We should never get here. */
		if (ei_debug)
			printk(KERN_DEBUG "%s: No Tx buffers free! irq=%ld tx1=%d tx2=%d last=%d\n",
				dev->name, dev->interrupt, ei_local->tx1, ei_local->tx2, ei_local->lasttx);
		ei_local->irqlock = 0;
		dev->tbusy = 1;
		outb_p(ENISR_ALL, e8390_base + EN0_IMR);
		spin_unlock(&ei_local->page_lock);
		enable_irq(dev->irq);
		ei_local->stat.tx_errors++;
		return 1;
	}

	/*
	 * Okay, now upload the packet and trigger a send if the transmitter
	 * isn't already sending. If it is busy, the interrupt handler will
	 * trigger the send later, upon receiving a Tx done interrupt.
	 */

	ei_block_output(dev, length, skb->data, output_page);
	if (! ei_local->txing)
	{
		ei_local->txing = 1;
		NS8390_trigger_send(dev, send_length, output_page);
		dev->trans_start = jiffies;
		if (output_page == ei_local->tx_start_page)
		{
			ei_local->tx1 = -1;
			ei_local->lasttx = -1;
		}
		else
		{
			ei_local->tx2 = -1;
			ei_local->lasttx = -2;
		}
	}
	else ei_local->txqueue++;

	dev->tbusy = (ei_local->tx1  &&  ei_local->tx2);

#else	/* EI_PINGPONG */

	/*
	 * Only one Tx buffer in use. You need two Tx bufs to come close to
	 * back-to-back transmits. Expect a 20 -> 25% performance hit on
	 * reasonable hardware if you only use one Tx buffer.
	 */

	ei_block_output(dev, length, skb->data, ei_local->tx_start_page);
	ei_local->txing = 1;
	NS8390_trigger_send(dev, send_length, ei_local->tx_start_page);
	dev->trans_start = jiffies;
	dev->tbusy = 1;

#endif	/* EI_PINGPONG */

	/* Turn 8390 interrupts back on. */
	ei_local->irqlock = 0;
	outb_p(ENISR_ALL, e8390_base + EN0_IMR);

	spin_unlock(&ei_local->page_lock);
	enable_irq(dev->irq);

	dev_kfree_skb (skb);
	ei_local->stat.tx_bytes += send_length;

	return 0;
}

/* The typical workload of the driver:
   Handle the ether interface interrupts. */

void ei_interrupt(int irq, void *dev_id, struct pt_regs * regs)
{
	struct device *dev = dev_id;
	long e8390_base;
	int interrupts, nr_serviced = 0;
	struct ei_device *ei_local;
        int tmp_interrupts;

	if (dev == NULL)
	{
		printk ("net_interrupt(): irq %d for unknown device.\n", irq);
		return;
	}

	e8390_base = dev->base_addr;
	ei_local = (struct ei_device *) dev->priv;

	/*
	 *	Protect the irq test too.
	 */

	spin_lock(&ei_local->page_lock);

	if (dev->interrupt || ei_local->irqlock)
	{
#if 1 /* This might just be an interrupt for a PCI device sharing this line */
		/* The "irqlock" check is only for testing. */
		printk(ei_local->irqlock
			   ? "%s: Interrupted while interrupts are masked! isr=%#2x imr=%#2x.\n"
			   : "%s: Reentering the interrupt handler! isr=%#2x imr=%#2x.\n",
			   dev->name, inb_p(e8390_base + EN0_ISR),
			   inb_p(e8390_base + EN0_IMR));
#endif
		spin_unlock(&ei_local->page_lock);
		return;
	}


	dev->interrupt = 1;

	/* Change to page 0 and read the intr status reg. */
	outb_p(E8390_NODMA+E8390_PAGE0, e8390_base + E8390_CMD);
	if (ei_debug > 3)
		printk(KERN_DEBUG "%s: interrupt(isr=%#2.2x).\n", dev->name,
			   inb_p(e8390_base + EN0_ISR));

	/* !!Assumption!! -- we stay in page 0.	 Don't break this. */
	while ((interrupts = inb_p(e8390_base + EN0_ISR)) != 0
		   && ++nr_serviced < MAX_SERVICE)
	{
		if (dev->start == 0)
		{
			printk(KERN_WARNING "%s: interrupt from stopped card\n", dev->name);
			interrupts = 0;
			break;
		}
                do {
                     outb_p(0, e8390_base + EN0_ISR);
                     outb_p(interrupts, e8390_base + EN0_ISR);
                     tmp_interrupts = inb_p(e8390_base + EN0_ISR);
		     interrupts |= tmp_interrupts;
		} while(tmp_interrupts);	//AX88190 Bug!
		if (interrupts & ENISR_OVER)
			ei_rx_overrun(dev);
		else if (interrupts & (ENISR_RX+ENISR_RX_ERR))
		{
			/* Got a good (?) packet. */
			ei_receive(dev);
		}
		/* Push the next to-transmit packet through. */
		if (interrupts & ENISR_TX)
			ei_tx_intr(dev);
		else if (interrupts & ENISR_TX_ERR)
			ei_tx_err(dev);

		if (interrupts & ENISR_COUNTERS)
		{
			ei_local->stat.rx_frame_errors += inb_p(e8390_base + EN0_COUNTER0);
			ei_local->stat.rx_crc_errors   += inb_p(e8390_base + EN0_COUNTER1);
			ei_local->stat.rx_missed_errors+= inb_p(e8390_base + EN0_COUNTER2);
			outb_p(ENISR_COUNTERS, e8390_base + EN0_ISR); /* Ack intr. */
		}

		/* Ignore any RDC interrupts that make it back to here. */
		if (interrupts & ENISR_RDC)
		{
			outb_p(ENISR_RDC, e8390_base + EN0_ISR);
		}

		outb_p(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base + E8390_CMD);
	}

	if (interrupts && ei_debug)
	{
		outb_p(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base + E8390_CMD);
		if (nr_serviced >= MAX_SERVICE)
		{
			printk(KERN_WARNING "%s: Too much work at interrupt, status %#2.2x\n",
				   dev->name, interrupts);
			outb_p(ENISR_ALL, e8390_base + EN0_ISR); /* Ack. most intrs. */
		} else {
			printk(KERN_WARNING "%s: unknown interrupt %#2x\n", dev->name, interrupts);
			outb_p(0xff, e8390_base + EN0_ISR); /* Ack. all intrs. */
		}
	}
	dev->interrupt = 0;
	spin_unlock(&ei_local->page_lock);
	return;
}

/*
 * A transmitter error has happened. Most likely excess collisions (which
 * is a fairly normal condition). If the error is one where the Tx will
 * have been aborted, we try and send another one right away, instead of
 * letting the failed packet sit and collect dust in the Tx buffer. This
 * is a much better solution as it avoids kernel based Tx timeouts, and
 * an unnecessary card reset.
 *
 * Called with lock held
 */

static void ei_tx_err(struct device *dev)
{
	long e8390_base = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	unsigned char txsr = inb_p(e8390_base+EN0_TSR);
	unsigned char tx_was_aborted = txsr & (ENTSR_ABT+ENTSR_FU);

#ifdef VERBOSE_ERROR_DUMP
	printk(KERN_DEBUG "%s: transmitter error (%#2x): ", dev->name, txsr);
	if (txsr & ENTSR_ABT)
		printk("excess-collisions ");
	if (txsr & ENTSR_ND)
		printk("non-deferral ");
	if (txsr & ENTSR_CRS)
		printk("lost-carrier ");
	if (txsr & ENTSR_FU)
		printk("FIFO-underrun ");
	if (txsr & ENTSR_CDH)
		printk("lost-heartbeat ");
	printk("\n");
#endif

	outb_p(ENISR_TX_ERR, e8390_base + EN0_ISR); /* Ack intr. */

	if (tx_was_aborted)
		ei_tx_intr(dev);
	else
	{
		ei_local->stat.tx_errors++;
		if (txsr & ENTSR_CRS) ei_local->stat.tx_carrier_errors++;
		if (txsr & ENTSR_CDH) ei_local->stat.tx_heartbeat_errors++;
		if (txsr & ENTSR_OWC) ei_local->stat.tx_window_errors++;
	}
}

/* We have finished a transmit: check for errors and then trigger the next
   packet to be sent. Called with lock held */

static void ei_tx_intr(struct device *dev)
{
	long e8390_base = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	int status = inb(e8390_base + EN0_TSR);

	outb_p(ENISR_TX, e8390_base + EN0_ISR); /* Ack intr. */

#ifdef EI_PINGPONG

	/*
	 * There are two Tx buffers, see which one finished, and trigger
	 * the send of another one if it exists.
	 */
	ei_local->txqueue--;

	if (ei_local->tx1 < 0)
	{
		if (ei_local->lasttx != 1 && ei_local->lasttx != -1)
			printk(KERN_ERR "%s: bogus last_tx_buffer %d, tx1=%d.\n",
				ei_local->name, ei_local->lasttx, ei_local->tx1);
		ei_local->tx1 = 0;
		dev->tbusy = 0;
		if (ei_local->tx2 > 0)
		{
			ei_local->txing = 1;
			NS8390_trigger_send(dev, ei_local->tx2, ei_local->tx_start_page + 6);
			dev->trans_start = jiffies;
			ei_local->tx2 = -1,
			ei_local->lasttx = 2;
		}
		else ei_local->lasttx = 20, ei_local->txing = 0;
	}
	else if (ei_local->tx2 < 0)
	{
		if (ei_local->lasttx != 2  &&  ei_local->lasttx != -2)
			printk("%s: bogus last_tx_buffer %d, tx2=%d.\n",
				ei_local->name, ei_local->lasttx, ei_local->tx2);
		ei_local->tx2 = 0;
		dev->tbusy = 0;
		if (ei_local->tx1 > 0)
		{
			ei_local->txing = 1;
			NS8390_trigger_send(dev, ei_local->tx1, ei_local->tx_start_page);
			dev->trans_start = jiffies;
			ei_local->tx1 = -1;
			ei_local->lasttx = 1;
		}
		else
			ei_local->lasttx = 10, ei_local->txing = 0;
	}
	else printk(KERN_WARNING "%s: unexpected TX-done interrupt, lasttx=%d.\n",
			dev->name, ei_local->lasttx);

#else	/* EI_PINGPONG */
	/*
	 *  Single Tx buffer: mark it free so another packet can be loaded.
	 */
	ei_local->txing = 0;
	dev->tbusy = 0;
#endif

	/* Minimize Tx latency: update the statistics after we restart TXing. */
	if (status & ENTSR_COL)
		ei_local->stat.collisions++;
	if (status & ENTSR_PTX)
		ei_local->stat.tx_packets++;
	else
	{
		ei_local->stat.tx_errors++;
		if (status & ENTSR_ABT)
		{
			ei_local->stat.tx_aborted_errors++;
			ei_local->stat.collisions += 16;
		}
		if (status & ENTSR_CRS)
			ei_local->stat.tx_carrier_errors++;
		if (status & ENTSR_FU)
			ei_local->stat.tx_fifo_errors++;
		if (status & ENTSR_CDH)
			ei_local->stat.tx_heartbeat_errors++;
		if (status & ENTSR_OWC)
			ei_local->stat.tx_window_errors++;
	}
	mark_bh (NET_BH);
}

/* We have a good packet(s), get it/them out of the buffers.
   Called with lock held */

static void ei_receive(struct device *dev)
{
	long e8390_base = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	unsigned char rxing_page, this_frame, next_frame;
	unsigned short current_offset;
	int rx_pkt_count = 0;
	struct e8390_pkt_hdr rx_frame;
	int num_rx_pages = ei_local->stop_page-ei_local->rx_start_page;

	while (++rx_pkt_count < 10)
	{
		int pkt_len, pkt_stat;

		/* Get the rx page (incoming packet pointer). */
		outb_p(E8390_NODMA+E8390_PAGE1, e8390_base + E8390_CMD);
		rxing_page = inb_p(e8390_base + EN1_CURPAG);
		outb_p(E8390_NODMA+E8390_PAGE0, e8390_base + E8390_CMD);

		/* Remove one frame from the ring.  Boundary is always a page behind. */
		this_frame = inb_p(e8390_base + EN0_BOUNDARY) + 1;
		if (this_frame >= ei_local->stop_page)
			this_frame = ei_local->rx_start_page;

		/* Someday we'll omit the previous, iff we never get this message.
		   (There is at least one clone claimed to have a problem.)  */
		if (ei_debug > 0  &&  this_frame != ei_local->current_page)
			printk(KERN_ERR "%s: mismatched read page pointers %2x vs %2x.\n",
				   dev->name, this_frame, ei_local->current_page);

		if (this_frame == rxing_page)	/* Read all the frames? */
			break;				/* Done for now */

		current_offset = this_frame << 8;
		ei_get_8390_hdr(dev, &rx_frame, this_frame);

		pkt_len = rx_frame.count - sizeof(struct e8390_pkt_hdr);
		pkt_stat = rx_frame.status;

		next_frame = this_frame + 1 + ((pkt_len+4)>>8);

		/* Check for bogosity warned by 3c503 book: the status byte is never
		   written.  This happened a lot during testing! This code should be
		   cleaned up someday. */
		if (rx_frame.next != next_frame
			&& rx_frame.next != next_frame + 1
			&& rx_frame.next != next_frame - num_rx_pages
			&& rx_frame.next != next_frame + 1 - num_rx_pages) {
			ei_local->current_page = rxing_page;
			outb(ei_local->current_page-1, e8390_base+EN0_BOUNDARY);
			ei_local->stat.rx_errors++;
			continue;
		}

		if (pkt_len < 60  ||  pkt_len > 1518)
		{
			if (ei_debug)
				printk(KERN_DEBUG "%s: bogus packet size: %d, status=%#2x nxpg=%#2x.\n",
					   dev->name, rx_frame.count, rx_frame.status,
					   rx_frame.next);
			ei_local->stat.rx_errors++;
			ei_local->stat.rx_length_errors++;
		}
		 else if ((pkt_stat & 0x0F) == ENRSR_RXOK)
		{
			struct sk_buff *skb;

			skb = dev_alloc_skb(pkt_len+2);
			if (skb == NULL)
			{
				if (ei_debug > 1)
					printk(KERN_DEBUG "%s: Couldn't allocate a sk_buff of size %d.\n",
						   dev->name, pkt_len);
				ei_local->stat.rx_dropped++;
				break;
			}
			else
			{
				skb_reserve(skb,2);	/* IP headers on 16 byte boundaries */
				skb->dev = dev;
				skb_put(skb, pkt_len);	/* Make room */
				ei_block_input(dev, pkt_len, skb, current_offset + sizeof(rx_frame));
				skb->protocol=eth_type_trans(skb,dev);
				netif_rx(skb);
				ei_local->stat.rx_packets++;
				ei_local->stat.rx_bytes += pkt_len;
				if (pkt_stat & ENRSR_PHY)
					ei_local->stat.multicast++;
			}
		}
		else
		{
			if (ei_debug)
				printk(KERN_DEBUG "%s: bogus packet: status=%#2x nxpg=%#2x size=%d\n",
					   dev->name, rx_frame.status, rx_frame.next,
					   rx_frame.count);
			ei_local->stat.rx_errors++;
			/* NB: The NIC counts CRC, frame and missed errors. */
			if (pkt_stat & ENRSR_FO)
				ei_local->stat.rx_fifo_errors++;
		}
		next_frame = rx_frame.next;

		/* This _should_ never happen: it's here for avoiding bad clones. */
		if (next_frame >= ei_local->stop_page) {
			printk("%s: next frame inconsistency, %#2x\n", dev->name,
				   next_frame);
			next_frame = ei_local->rx_start_page;
		}
		ei_local->current_page = next_frame;
		outb_p(next_frame-1, e8390_base+EN0_BOUNDARY);
	}

	/* We used to also ack ENISR_OVER here, but that would sometimes mask
	   a real overrun, leaving the 8390 in a stopped state with rec'vr off. */
	outb_p(ENISR_RX+ENISR_RX_ERR, e8390_base+EN0_ISR);
	return;
}

/*
 * We have a receiver overrun: we have to kick the 8390 to get it started
 * again. Problem is that you have to kick it exactly as NS prescribes in
 * the updated datasheets, or "the NIC may act in an unpredictable manner."
 * This includes causing "the NIC to defer indefinitely when it is stopped
 * on a busy network."  Ugh.
 * Called with lock held. Don't call this with the interrupts off or your
 * computer will hate you - it takes 10mS or so.
 */

static void ei_rx_overrun(struct device *dev)
{
	long e8390_base = dev->base_addr;
	unsigned char was_txing, must_resend = 0;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;

	/*
	 * Record whether a Tx was in progress and then issue the
	 * stop command.
	 */
	was_txing = inb_p(e8390_base+E8390_CMD) & E8390_TRANS;
	outb_p(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD);

	if (ei_debug > 1)
		printk(KERN_DEBUG "%s: Receiver overrun.\n", dev->name);
	ei_local->stat.rx_over_errors++;

	/*
	 * Wait a full Tx time (1.2ms) + some guard time, NS says 1.6ms total.
	 * Early datasheets said to poll the reset bit, but now they say that
	 * it "is not a reliable indicator and subsequently should be ignored."
	 * We wait at least 10ms.
	 */

	udelay(10*1000);

	/*
	 * Reset RBCR[01] back to zero as per magic incantation.
	 */
	outb_p(0x00, e8390_base+EN0_RCNTLO);
	outb_p(0x00, e8390_base+EN0_RCNTHI);

	/*
	 * See if any Tx was interrupted or not. According to NS, this
	 * step is vital, and skipping it will cause no end of havoc.
	 */

	if (was_txing)
	{
		unsigned char tx_completed = inb_p(e8390_base+EN0_ISR) & (ENISR_TX+ENISR_TX_ERR);
		if (!tx_completed)
			must_resend = 1;
	}

	/*
	 * Have to enter loopback mode and then restart the NIC before
	 * you are allowed to slurp packets up off the ring.
	 */
	outb_p(E8390_TXOFF, e8390_base + EN0_TXCR);
	outb_p(E8390_NODMA + E8390_PAGE0 + E8390_START, e8390_base + E8390_CMD);

	/*
	 * Clear the Rx ring of all the debris, and ack the interrupt.
	 */
	ei_receive(dev);
	outb_p(ENISR_OVER, e8390_base+EN0_ISR);

	/*
	 * Leave loopback mode, and resend any packet that got stopped.
	 */
	outb_p(E8390_TXCONFIG | ei_local->NicTransmitConfig, e8390_base + EN0_TXCR);
	if (must_resend)
    		outb_p(E8390_NODMA + E8390_PAGE0 + E8390_START + E8390_TRANS, e8390_base + E8390_CMD);
}

/*
 *	Collect the stats. This is called unlocked and from several contexts.
 */

static struct net_device_stats *get_stats(struct device *dev)
{
	long ioaddr = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	unsigned long flags;

	/* If the card is stopped, just return the present stats. */
	if (dev->start == 0)
		return &ei_local->stat;

	spin_lock_irqsave(&ei_local->page_lock,flags);
	/* Read the counter registers, assuming we are in page 0. */
	ei_local->stat.rx_frame_errors += inb_p(ioaddr + EN0_COUNTER0);
	ei_local->stat.rx_crc_errors   += inb_p(ioaddr + EN0_COUNTER1);
	ei_local->stat.rx_missed_errors+= inb_p(ioaddr + EN0_COUNTER2);
	spin_unlock_irqrestore(&ei_local->page_lock, flags);

	return &ei_local->stat;
}

/*
 * Update the given Autodin II CRC value with another data byte.
 */

static inline u32 update_crc(u8 byte, u32 current_crc)
{
	int bit;
	u8 ah = 0;
	for (bit=0; bit<8; bit++)
	{
		u8 carry = (current_crc>>31);
		current_crc <<= 1;
		ah = ((ah<<1) | carry) ^ byte;
		if (ah&1)
			current_crc ^= 0x04C11DB7;	/* CRC polynomial */
		ah >>= 1;
		byte >>= 1;
	}
	return current_crc;
}

/*
 * Form the 64 bit 8390 multicast table from the linked list of addresses
 * associated with this dev structure.
 */

static inline void make_mc_bits(u8 *bits, struct device *dev)
{
	struct dev_mc_list *dmi;

	for (dmi=dev->mc_list; dmi; dmi=dmi->next)
	{
		int i;
		u32 crc;
		if (dmi->dmi_addrlen != ETH_ALEN)
		{
			printk(KERN_INFO "%s: invalid multicast address length given.\n", dev->name);
			continue;
		}
		crc = 0xffffffff;	/* initial CRC value */
		for (i=0; i<ETH_ALEN; i++)
			crc = update_crc(dmi->dmi_addr[i], crc);
		/*
		 * The 8390 uses the 6 most significant bits of the
		 * CRC to index the multicast table.
		 */
		bits[crc>>29] |= (1<<((crc>>26)&7));
	}
}

/*
 *	Set or clear the multicast filter for this adaptor. May be called
 *	from a BH in 2.1.x. Must be called with lock held.
 */

static void do_set_multicast_list(struct device *dev)
{
	long e8390_base = dev->base_addr;
	int i;
	struct ei_device *ei_local = (struct ei_device*)dev->priv;

	if (!(dev->flags&(IFF_PROMISC|IFF_ALLMULTI)))
	{
		memset(ei_local->mcfilter, 0, 8);
		if (dev->mc_list)
			make_mc_bits(ei_local->mcfilter, dev);
	}
	else
		memset(ei_local->mcfilter, 0xFF, 8);	/* mcast set to accept-all */

	/*
	 * DP8390 manuals don't specify any magic sequence for altering
	 * the multicast regs on an already running card. To be safe, we
	 * ensure multicast mode is off prior to loading up the new hash
	 * table. If this proves to be not enough, we can always resort
	 * to stopping the NIC, loading the table and then restarting.
	 *
	 * Bug Alert!  The MC regs on the SMC 83C690 (SMC Elite and SMC
	 * Elite16) appear to be write-only. The NS 8390 data sheet lists
	 * them as r/w so this is a bug.  The SMC 83C790 (SMC Ultra and
	 * Ultra32 EISA) appears to have this bug fixed.
	 */

	if (dev->start)
		outb_p(E8390_RXCONFIG | 0x40, e8390_base + EN0_RXCR);
	outb_p(E8390_NODMA + E8390_PAGE1, e8390_base + E8390_CMD);
	for(i = 0; i < 8; i++)
	{
		outb_p(ei_local->mcfilter[i], e8390_base + EN1_MULT_SHIFT(i));
#ifndef BUG_83C690
		if(inb_p(e8390_base + EN1_MULT_SHIFT(i))!=ei_local->mcfilter[i])
			printk(KERN_ERR "Multicast filter read/write mismap %d\n",i);
#endif
	}
	outb_p(E8390_NODMA + E8390_PAGE0, e8390_base + E8390_CMD);

  	if(dev->flags&IFF_PROMISC)
  		outb_p(E8390_RXCONFIG | 0x18 | 0x40, e8390_base + EN0_RXCR);
	else if(dev->flags&IFF_ALLMULTI || dev->mc_list)
  		outb_p(E8390_RXCONFIG | 0x08 | 0x40, e8390_base + EN0_RXCR);
  	else
  		outb_p(E8390_RXCONFIG | 0x40, e8390_base + EN0_RXCR);
 }

/*
 *	Called without lock held. This is invoked from user context and may
 *	be parallel to just about everything else. Its also fairly quick and
 *	not called too often. Must protect against both bh and irq users
 */

static void set_multicast_list(struct device *dev)
{
	unsigned long flags;
	struct ei_device *ei_local = (struct ei_device*)dev->priv;

	spin_lock_irqsave(&ei_local->page_lock, flags);
	do_set_multicast_list(dev);
	spin_unlock_irqrestore(&ei_local->page_lock, flags);
}

/*
 * Initialize the rest of the 8390 device structure.  Do NOT __initfunc
 * this, as it is used by 8390 based modular drivers too.
 */

int ethdev_init(struct device *dev)
{
/*	if (ei_debug > 1) */
		printk(KERN_INFO "%s \n", version);

	if (dev->priv == NULL)
	{
		struct ei_device *ei_local;

		dev->priv = kmalloc(sizeof(struct ei_device), GFP_KERNEL);
		if (dev->priv == NULL)
			return -ENOMEM;
		memset(dev->priv, 0, sizeof(struct ei_device));
		ei_local = (struct ei_device *)dev->priv;
		spin_lock_init(&ei_local->page_lock);
	}

	dev->hard_start_xmit = &ei_start_xmit;
	dev->get_stats	= get_stats;
	dev->set_multicast_list = &set_multicast_list;

	ether_setup(dev);

	return 0;
}



/* This page of functions should be 8390 generic */
/* Follow National Semi's recommendations for initializing the "NIC". */

/*
 *	Must be called with lock held.
 */

void NS8390_init(struct device *dev, int startp)
{
	long e8390_base = dev->base_addr;
	struct ei_device *ei_local = (struct ei_device *) dev->priv;
	int i;
	int endcfg = ei_local->word16 ? (0x48 | ENDCFG_WTS) : 0x48;

	if(sizeof(struct e8390_pkt_hdr)!=4)
    		panic("88790.c: header struct mispacked\n");
	/* Follow National Semi's recommendations for initing the DP83902. */
	outb_p(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD); /* 0x21 */
	outb_p(endcfg, e8390_base + EN0_DCFG);	/* 0x48 or 0x49 */
	/* Clear the remote byte count registers. */
	outb_p(0x00,  e8390_base + EN0_RCNTLO);
	outb_p(0x00,  e8390_base + EN0_RCNTHI);
	/* Set to monitor and loopback mode -- this is vital!. */
	outb_p(E8390_RXOFF | 0x40, e8390_base + EN0_RXCR); /* 0x20 */
	outb_p(E8390_TXOFF, e8390_base + EN0_TXCR); /* 0x02 */
	/* Set the transmit page and receive ring. */
	outb_p(ei_local->tx_start_page, e8390_base + EN0_TPSR);
	ei_local->tx1 = ei_local->tx2 = 0;
	outb_p(ei_local->rx_start_page, e8390_base + EN0_STARTPG);
	outb_p(ei_local->stop_page-1, e8390_base + EN0_BOUNDARY);	/* 3c503 says 0x3f,NS0x26*/
	ei_local->current_page = ei_local->rx_start_page;		/* assert boundary+1 */
	outb_p(ei_local->stop_page, e8390_base + EN0_STOPPG);
	/* Clear the pending interrupts and mask. */
	outb_p(0xFF, e8390_base + EN0_ISR);
	outb_p(0x00,  e8390_base + EN0_IMR);

	/* Copy the station address into the DS8390 registers. */

	outb_p(E8390_NODMA + E8390_PAGE1 + E8390_STOP, e8390_base+E8390_CMD); /* 0x61 */
	for(i = 0; i < 6; i++)
	{
		outb_p(dev->dev_addr[i], e8390_base + EN1_PHYS_SHIFT(i));
		if(inb_p(e8390_base + EN1_PHYS_SHIFT(i))!=dev->dev_addr[i])
			printk(KERN_ERR "Hw. address read/write mismap %d\n",i);
	}

	outb_p(ei_local->rx_start_page, e8390_base + EN1_CURPAG);
	outb_p(E8390_NODMA+E8390_PAGE0+E8390_STOP, e8390_base+E8390_CMD);

	dev->tbusy = 0;
	dev->interrupt = 0;
	ei_local->tx1 = ei_local->tx2 = 0;
	ei_local->txing = 0;

	if (startp)
	{
		outb_p(0xff,  e8390_base + EN0_ISR);
		outb_p(ENISR_ALL,  e8390_base + EN0_IMR);
		outb_p(E8390_NODMA+E8390_PAGE0+E8390_START, e8390_base+E8390_CMD);
		outb_p(E8390_TXCONFIG | ei_local->NicTransmitConfig, e8390_base + EN0_TXCR); /* xmit on. */
		/* 3c503 TechMan says rxconfig only after the NIC is started. */
		outb_p(E8390_RXCONFIG | 0x40, e8390_base + EN0_RXCR); /* rx on,  */
		do_set_multicast_list(dev);	/* (re)load the mcast table */
	}
	return;
}

/* Trigger a transmit start, assuming the length is valid.
   Always called with the page lock held */

static void NS8390_trigger_send(struct device *dev, unsigned int length,
								int start_page)
{
	long e8390_base = dev->base_addr;
 	struct ei_device *ei_local = (struct ei_device *) dev->priv;

	outb_p(E8390_NODMA+E8390_PAGE0, e8390_base+E8390_CMD);

	if (inb_p(e8390_base) & E8390_TRANS)
	{
		printk(KERN_WARNING "%s: trigger_send() called with the transmitter busy.\n",
			dev->name);
		return;
	}
	outb_p(length & 0xff, e8390_base + EN0_TCNTLO);
	outb_p(length >> 8, e8390_base + EN0_TCNTHI);
	outb_p(start_page, e8390_base + EN0_TPSR);
	outb_p(E8390_NODMA+E8390_TRANS+E8390_START, e8390_base+E8390_CMD);
}


/* Mii functions start */

static void
inb_px(long port, unsigned char *value)
{
    *value = inb_p(port);
}


#define TCR_FULL_DUPLEX 0x80

#define	outp(_Port,_Value)	\
    outb_p((UCHAR)(_Value), (_Port))

#define	inp(_Port,_Value)	\
	inb_px((_Port), (PUCHAR)(_Value))

#define	IOBase		(dev->base_addr)
// Definition for AX8819x
#define a19x_CR 	(IOBase)
// Read Page 0
#define a19x_CLDA0	(IOBase+0x01)
#define a19x_CLDA1	(IOBase+0x02)
#define a19x_BNRY	(IOBase+0x03)
#define a19x_TSR	(IOBase+0x04)
#define a19x_NCR	(IOBase+0x05)
#define a19x_CURR	(IOBase+0x06)
#define a19x_ISR	(IOBase+0x07)
#define a19x_CRDA0	(IOBase+0x08)
#define a19x_CRDA1	(IOBase+0x09)
#define a19x_RSV01	(IOBase+0x0A)
#define a19x_RSV02	(IOBase+0x0B)
#define a19x_RSR	(IOBase+0x0C)
#define a19x_CNTR0	(IOBase+0x0D)
#define a19x_CNTR1	(IOBase+0x0E)
#define a19x_CNTR2	(IOBase+0x0F)
// Write Page 0
#define a19x_PSTART	a19x_CLDA0
#define a19x_PSTOP	a19x_CLDA1
#define a19x_TPSR	a19x_TSR
#define a19x_TBCR0	a19x_NCR
#define a19x_TBCR1	a19x_CURR
#define a19x_RSAR0	a19x_CRDA0
#define a19x_RSAR1	a19x_CRDA1
#define a19x_RBAR0	a19x_RSV01
#define a19x_RBAR1	a19x_RSV02
#define a19x_RCR	a19x_RSR
#define a19x_TCR	a19x_CNTR0
#define a19x_DCR	a19x_CNTR1
#define a19x_IMR	a19x_CNTR2
// Read/Write Page 1
#define a19x_PAR0	a19x_CLDA0
#define a19x_PAR1	a19x_CLDA1
#define a19x_PAR2	a19x_BNRY
#define a19x_PAR3	a19x_TSR
#define a19x_PAR4	a19x_NCR
#define a19x_PAR5	a19x_CURR
#define a19x_MAR0	a19x_CRDA0
#define a19x_MAR1	a19x_CRDA1
#define a19x_MAR2	a19x_RSV01
#define a19x_MAR3	a19x_RSV02
#define a19x_MAR4	a19x_RSR
#define a19x_MAR5	a19x_CNTR0
#define a19x_MAR6	a19x_CNTR1
#define a19x_MAR7	a19x_CNTR2
// independent port
#define a19x_DATA	(IOBase+0x10)
#define a19x_IFGS1	(IOBase+0x12)
#define a19x_IFGS2	(IOBase+0x13)
#define a19x_MEMR	(IOBase+0x14)	//peripheral(SROM, PHY) data access
#define a19x_TEST	(IOBase+0x15)
#define a19x_IFG	(IOBase+0x16)
#define a19x_RESET	(IOBase+0x1F)

#define MII_MDO_BIT_POSITION	3
#define MII_MDO_MASK		8
#define MII_WRITE		0
#define MII_READ		2
#define MII_CLK 		1

//***************************************************************************
// Write data to MII
//***************************************************************************
static void
A19xWriteMii(
		IN struct device *dev,
		IN ULONG		ulData,
		IN USHORT		uDataSize
		)
{
	for (; uDataSize > 0; uDataSize--)
	{
		ULONG ulDataBit;

		ulDataBit = (ulData >> (31 - MII_MDO_BIT_POSITION)) & MII_MDO_MASK;
		outp(a19x_MEMR, MII_WRITE |ulDataBit);
		outp(a19x_MEMR, MII_WRITE |MII_CLK |ulDataBit);
		ulData <<= 1;
	}
}

#define MII_WRITE_TS			2	//

//***************************************************************************
// Set MII to three-state
//***************************************************************************
#define MiiOut3State	{outp(a19x_MEMR, MII_WRITE_TS); \
			outp(a19x_MEMR, MII_WRITE_TS |MII_CLK);}

#define PHY_ADDR_ALIGN		23	// shift
#define REG_ADDR_ALIGN		18	// shift
#define PRE					((ULONG)(0xFFFFFFFF))
#define MII_READ_FRAME		((ULONG)(0x60000000))
#define MII_WRITE_FRAME 	((ULONG)(0x50020000))
#define MII_MDI_BIT_POSITION	2
#define MII_MDI_MASK		4
#define MII_READ_DATA_MASK	MII_MDI_MASK

#define MiiPhyCtrlReservedBitsMask	((USHORT) 0x007F)
#define MiiPhyStatReservedBitsMask	((USHORT) 0x07C0)
#define MiiPhyNwayReservedBitsMask	((USHORT) 0x1C00)
#define MiiPhyNwayExpReservedBitsMask		((USHORT) 0xFFE0)

//Data Structure holding PHY's registers mask
static const USHORT PhyRegsReservedBitsMasks[] = {

  MiiPhyCtrlReservedBitsMask,	// Control reg reserved bits mask
  MiiPhyStatReservedBitsMask,	// Status reg reserved bits
  0,							// PhyID reserved bits mask
  0,							// PhyID reserved bits mask
  MiiPhyNwayReservedBitsMask,	// Nway Local ability reserved bits mask
  MiiPhyNwayReservedBitsMask,	// Nway Partner ability reserved bits mask
  MiiPhyNwayExpReservedBitsMask,// Nway Expansion
  0,0,0,0,0,0,0,0,0,0,0,0,0,	// Other regs
  0,0,0,0,0,0,0,0,0,0,0,0		// Other regs
  };

//***************************************************************************
// Read the value of the MII register
//***************************************************************************
static INT
MiiReadRegister(
		IN struct device *dev,
		IN USHORT		uPhyAddr,
		IN USHORT		uRegNum,
		OUT PUSHORT		puRegData
		)
{
	ULONG	ulCommand = (uPhyAddr <<PHY_ADDR_ALIGN)
			|(uRegNum <<REG_ADDR_ALIGN)
			|MII_READ_FRAME;
	USHORT	uBitsOfUshort = sizeof(USHORT) * 8;
	USHORT	i;
	UCHAR	iTemp;

	*puRegData = 0;

	A19xWriteMii(dev, 0, 16);
	A19xWriteMii(dev, PRE, (USHORT)(2*uBitsOfUshort));
	A19xWriteMii(dev, ulCommand, (USHORT)(uBitsOfUshort-2));
	MiiOut3State;

	inp(a19x_MEMR, &iTemp);
	if (iTemp & MII_READ_DATA_MASK)
	{
		// TRY AGAIN!
		// some kind of PHY need to do this twice...
		MiiOut3State;
		inp(a19x_MEMR, &iTemp);
		if (iTemp & MII_READ_DATA_MASK)
			return AX_FALSE;
	}
	for (i = 0; i < uBitsOfUshort; i++)
	{
		outp(a19x_MEMR, MII_READ);
		outp(a19x_MEMR, MII_READ | MII_CLK);

		inp(a19x_MEMR, &iTemp);
		*puRegData = (*puRegData << 1) |(USHORT)((iTemp >> MII_MDI_BIT_POSITION) & 0x0001);
	}
	MiiOut3State;

	*puRegData &= ~PhyRegsReservedBitsMasks[uRegNum];

	return AX_TRUE;
}

//***************************************************************************
// Write the value to the MII register
//***************************************************************************
static void
MiiWriteRegister(
		IN struct device *dev,
		IN USHORT		uPhyAddr,
		IN USHORT		uRegNum,
		IN USHORT		uRegData
		)
{
	ULONG	ulCommand = (uPhyAddr <<PHY_ADDR_ALIGN)
			|(uRegNum <<REG_ADDR_ALIGN)
			|MII_WRITE_FRAME
			|(uRegData & ~PhyRegsReservedBitsMasks[uRegNum]);
	USHORT	uBitsOfUshort = sizeof(USHORT) * 8;

	A19xWriteMii(dev, 0, 16);
	A19xWriteMii(dev, PRE, (USHORT)(2*uBitsOfUshort));
	A19xWriteMii(dev, ulCommand, (USHORT)(2*uBitsOfUshort));
	MiiOut3State;
}


#define MiiPhyCtrlReset 		((USHORT) 0x8000)
#define MiiPhyCtrlLoopBack		((USHORT) 0x4000)
#define MiiPhyCtrlSpeed100		((USHORT) 0x2000)
#define MiiPhyCtrlEnableNway	((USHORT) 0x1000)
#define MiiPhyCtrlPowerDown		((USHORT) 0x0800)
#define MiiPhyCtrlIsolate		((USHORT) 0x0400)
#define MiiPhyCtrlRestartNway	((USHORT) 0x0200)
#define MiiPhyCtrlDuplexMode	((USHORT) 0x0100)
#define MiiPhyCtrlCollisionTest 	((USHORT) 0x0080)
#define MiiPhyCtrlReservedBitsMask	((USHORT) 0x007F)
#define MiiPhyCtrlForce10		((USHORT) 0xCEFF)

#define MiiPhy100BaseT4 		((USHORT) 0x8000)
#define MiiPhy100BaseTxFD		((USHORT) 0x4000)
#define MiiPhy100BaseTx 		((USHORT) 0x2000)
#define MiiPhy10BaseTFD 		((USHORT) 0x1000)
#define MiiPhy10BaseT			((USHORT) 0x0800)
#define MiiPhyStatReservedBitsMask	((USHORT) 0x07C0)
#define MiiPhyNwayComplete		((USHORT) 0x0020)
#define MiiPhyRemoteFault		((USHORT) 0x0010)
#define MiiPhyNwayCapable		((USHORT) 0x0008)
#define MiiPhyLinkStatus		((USHORT) 0x0004)
#define MiiPhyJabberDetect		((USHORT) 0x0002)
#define MiiPhyExtendedCapabilities	((USHORT) 0x0001)

#define MiiPhyNwayNextPageAble	((USHORT) 0x8000)
#define MiiPhyNwayACK			((USHORT) 0x4000)
#define MiiPhyNwayRemoteFault	((USHORT) 0x2000)
#define MiiPhyNwayReservedBitsMask	((USHORT) 0x1C00)
#define MiiPhyNway100BaseT4		((USHORT) 0x0200)
#define MiiPhyNway100BaseTxFD	((USHORT) 0x0100)
#define MiiPhyNway100BaseTx		((USHORT) 0x0080)
#define MiiPhyNway10BaseTFD		((USHORT) 0x0040)
#define MiiPhyNway10BaseT		((USHORT) 0x0020)
#define MiiPhyNwaySelectorMask	((USHORT) 0x001F)

#define MiiPhyNwayExpReservedBitsMask		((USHORT) 0xFFE0)
#define MiiPhyNwayExpMultipleLinkFault		((USHORT) 0x0010)
#define MiiPhyNwayExpLinkPartnerNextPageAble	((USHORT) 0x0008)
#define MiiPhyNwayExpNextPageAble			((USHORT) 0x0004)
#define MiiPhyNwayExpReceivedLinkCodePage	((USHORT) 0x0002)
#define MiiPhyNwayExpLinkPartnerNwayAble	((USHORT) 0x0001)

// MII PHY Register's
#define  PhyControlReg				0
#define  PhyStatusReg				1
#define  PhyId_1					2
#define  PhyId_2					3
#define  PhyNwayAdvertisement		4
#define  PhyNwayLinkPartnerAbility	5
#define  PhyNwayExpansion			6
#define  PhyNwayNextPageTransmit	7
#define  PhyReserved				8	// 8-15	are PHY's reserved
#define  PhyVendorSpecific			16	// 16-31 are Vendor's Specific
#define  NatPhyParRegister			25
#define  MAX_PHY_REGS				32


static INT
AXSearchPhy(
	IN struct device *dev
	)
{
    struct ei_device *ei_local = (struct ei_device *) dev->priv;
	USHORT	uPhyAddr = 0;
	USHORT	uPhyId_1;
	USHORT	uPhyId_2;

	// Search for the Phy address
	while (uPhyAddr < 32)
	{
		USHORT	uPhyStatusReg;
		USHORT	uPhyCtrlReg;

		if (MiiReadRegister(
				dev,
				uPhyAddr,
				PhyStatusReg,
				&uPhyStatusReg)
			&& MiiReadRegister(
				dev,
				uPhyAddr,
				PhyControlReg,
				&uPhyCtrlReg))
		    break;		// A real PHY found!
		uPhyAddr++;		// try next...
	}
	if (uPhyAddr >= 32)
		return AX_FALSE;

	ei_local->uPhyAddr = uPhyAddr;

	MiiReadRegister(
		dev,
		uPhyAddr,
		PhyId_1,
		&uPhyId_1
	);
	MiiReadRegister(
		dev,
		uPhyAddr,
		PhyId_2,
		&uPhyId_2
	);
	ei_local->ulPhyId = (uPhyId_1 << 16) + (uPhyId_2 & 0xFFF0);
	return AX_TRUE;
}


//***************************************************************************
// Initiate the Phys in MII mode
//***************************************************************************
static void
AXInitPhy(
	IN struct device *dev
	 )
{
    struct ei_device *ei_local = (struct ei_device *) dev->priv;
	USHORT	uPhyCtrlReg;
	USHORT	uPhyAddr = ei_local->uPhyAddr;

	// Reset the Phy
	MiiWriteRegister(
		dev,
		uPhyAddr,
		PhyControlReg,
		MiiPhyCtrlReset
		);
	do
	{
	    udelay(1000);
		MiiReadRegister(
			dev,
			uPhyAddr,
			PhyControlReg,
			&uPhyCtrlReg
			);
	} while (uPhyCtrlReg & MiiPhyCtrlReset);

	if (ei_local->uForcedConnectionType != 0)
		switch (ei_local->uForcedConnectionType)
		{
		case 2:
			uPhyCtrlReg = 0;
			break;
		case 3:
			uPhyCtrlReg = MiiPhyCtrlDuplexMode;
			ei_local->NicTransmitConfig |= TCR_FULL_DUPLEX;
			break;
		case 8:
			uPhyCtrlReg = MiiPhyCtrlSpeed100;
			break;
		case 9:
			uPhyCtrlReg = MiiPhyCtrlSpeed100 |MiiPhyCtrlDuplexMode;
			ei_local->NicTransmitConfig |= TCR_FULL_DUPLEX;
			break;
		default:
			ei_local->uForcedConnectionType = 0;
			break;
		}
	ei_local->uConnectionType = ei_local->uForcedConnectionType;
	if (ei_local->uConnectionType != 0)
	{
		MiiWriteRegister(
			dev,
			uPhyAddr,
			PhyControlReg,
			uPhyCtrlReg
			);
	}
	else
	{
		///
		// Auto-negotiation mode
		///
		USHORT j;
		USHORT	uPhyStatusReg;
			// Set the Phy to auto-negotiation mode
		uPhyCtrlReg = MiiPhyCtrlEnableNway | MiiPhyCtrlRestartNway;
		MiiWriteRegister(
			dev,
			uPhyAddr,
			PhyControlReg,
			uPhyCtrlReg
			);
		for (j = 0; j < 4; j++)
		{
			MiiReadRegister(
				dev,
				uPhyAddr,
				PhyStatusReg,
				&uPhyStatusReg
				);
			if (uPhyStatusReg & MiiPhyNwayComplete) {
				printk(KERN_INFO "MiiPhyNwayComplete \n");
				break;
			}
 		        udelay(1000000);
		}
	}

	return;
}

// Media modes
/*
#define MEDIA_NWAY		0x0100
#define MEDIA_FULL_DUPLEX	0x0200
#define MEDIA_LINK_DISABLE	0x0400
#define MEDIA_AUTOSENSE		0x0800
#define MEDIA_NODYNAMIC		0x8000
*/

// MII PHY Register's
#define  PhyControlReg			0
#define  PhyStatusReg			1
#define  PhyId_1			2
#define  PhyId_2			3
#define  PhyNwayAdvertisement		4
#define  PhyNwayLinkPartnerAbility	5
#define  PhyNwayExpansion		6
#define  PhyNwayNextPageTransmit	7
#define  PhyReserved			8	// 8-15	are PHY's reserved
#define  PhyVendorSpecific		16	// 16-31 are Vendor's Specific
#define  NatPhyParRegister		25
#define  MAX_PHY_REGS			32

//!!! bit 0..3 (PHY revision) should be ignored and reset!!!
#define TIE2101_0		0x40005030
#define BCM5000_0		0x03E00000
#define DP83840_0		0x20005C00
#define ICS1890_0		0x0015f420
#define QSI6612_0		0x01814400
#define LUC6612_0		0x018074C0
#define MTD972_0		0x00000000
#define MTD972_1		0x0302D000
#define DM9101_0		0x0181B800
#define LXT970_0		0x78100000

#define  MiiPhyStat100BaseTxFD	0x100
#define  MiiPhyStat100BaseTx	0x080
#define  MiiPhyStat10BaseTxFD	0x040
#define  MiiPhyStat10BaseTx	0x020

#define MiiPhy100BaseT4 		((USHORT) 0x8000)
#define MiiPhy100BaseTxFD		((USHORT) 0x4000)
#define MiiPhy100BaseTx 		((USHORT) 0x2000)
#define MiiPhy10BaseTFD 		((USHORT) 0x1000)
#define MiiPhy10BaseT			((USHORT) 0x0800)
#define MiiPhyStatReservedBitsMask	((USHORT) 0x07C0)
#define MiiPhyNwayComplete		((USHORT) 0x0020)
#define MiiPhyRemoteFault		((USHORT) 0x0010)
#define MiiPhyNwayCapable		((USHORT) 0x0008)
#define MiiPhyLinkStatus		((USHORT) 0x0004)
#define MiiPhyJabberDetect		((USHORT) 0x0002)
#define MiiPhyExtendedCapabilities	((USHORT) 0x0001)


static INT
MediaModeChanged(
    IN struct device *dev
    )
{
    struct ei_device *ei_local = (struct ei_device *) dev->priv;
	USHORT	uConnectionMode;
	ULONG	ulOperationMode;

	printk(KERN_INFO "PhyId is %lx\n",ei_local->ulPhyId);
	printk(KERN_INFO "uPhyAddr is %x\n",ei_local->uPhyAddr);
	switch (ei_local->ulPhyId)
	{
		USHORT uTmp;
	case QSI6612_0 :
		printk(KERN_INFO "QSI6612_0\n");
		MiiReadRegister(dev, ei_local->uPhyAddr, 0x1f, &uTmp);
		switch (uTmp & 0x1c)
		{
		case 0x08 :
			uConnectionMode = MiiPhyStat100BaseTx;
			break;
		case 0x18 :
			uConnectionMode = MiiPhyStat100BaseTxFD;
			break;
		case 0x14 :
			uConnectionMode = MiiPhyStat10BaseTxFD;
			break;
		case 0x04 :
		default :
			uConnectionMode = MiiPhyStat10BaseTx;
			break;
		}
		break;
	case DM9101_0 :
		printk(KERN_INFO "DM9101_0\n");
		MiiReadRegister(dev, ei_local->uPhyAddr, 0x11, &uTmp);
		if (uTmp & 0x8000)
			uConnectionMode = MiiPhyStat100BaseTxFD;
		else
			if (uTmp & 0x4000)
				uConnectionMode = MiiPhyStat100BaseTx;
			else
				if (uTmp & 0x2000)
					uConnectionMode = MiiPhyStat10BaseTxFD;
				else
					uConnectionMode = MiiPhyStat10BaseTx;
		break;
	default :
		printk(KERN_INFO "default \n");
		{
			USHORT	uLocalAbility, uPartnerAbility;

			MiiReadRegister(
				dev,
				ei_local->uPhyAddr,
				PhyNwayAdvertisement,
				&uLocalAbility
				);
			MiiReadRegister(
				dev,
				ei_local->uPhyAddr,
				PhyNwayLinkPartnerAbility,
				&uPartnerAbility
				);
			printk(KERN_INFO "uLocalAbility is %x\n",uLocalAbility);
			printk(KERN_INFO "uPartnerAbility is %x\n",uPartnerAbility);
			uConnectionMode = (uLocalAbility & uPartnerAbility & 0x1E0);
			printk(KERN_INFO "uConnectionMode is %x\n",uConnectionMode);
			if (uConnectionMode)
				break;
		}


		switch (ei_local->ulPhyId)
		{
		case MTD972_0 :
		case MTD972_1 :
		case DP83840_0 :
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x19, &uTmp);
			if (uTmp & 0x40)
				uConnectionMode = MiiPhyStat10BaseTx;
			else
				uConnectionMode = MiiPhyStat100BaseTx;
			break;
		case ICS1890_0 :
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x11, &uTmp);
			if (uTmp & 0x8000)
				uConnectionMode = MiiPhyStat100BaseTx;
			else
				uConnectionMode = MiiPhyStat10BaseTx;
			break;
		case LXT970_0 :
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x14, &uTmp);
			if ((uTmp & 0x1800) ==0x1800)
				uConnectionMode = MiiPhyStat100BaseTxFD;
			else
				if (uTmp & 0x800)
					uConnectionMode = MiiPhyStat100BaseTx;
				else
					if (uTmp & 0x1000)
						uConnectionMode = MiiPhyStat10BaseTxFD;
					else
						uConnectionMode = MiiPhyStat10BaseTx;
			break;
		case LUC6612_0 :
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x1C, &uTmp);
			if (uTmp & 2)
				uConnectionMode = MiiPhyStat10BaseTx;
			else
				uConnectionMode = MiiPhyStat100BaseTx;
			break;
		case TIE2101_0 :
			// read first time to clear the possible latch bits.
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x12, &uTmp);
			// Get the real data
			MiiReadRegister(dev, ei_local->uPhyAddr, 0x12, &uTmp);
			if (uTmp & 0x800)
				uConnectionMode = MiiPhyStat10BaseTx;
			else
				uConnectionMode = MiiPhyStat100BaseTx;
			break;
		default :
			uConnectionMode = MiiPhyStat100BaseTx;
			break;
		}
	}

	if (uConnectionMode == ei_local->uConnectionMode)
		return AX_FALSE;
	ei_local->uConnectionMode = uConnectionMode;

	if ((uConnectionMode & MiiPhyStat100BaseTxFD) ||
		(uConnectionMode & MiiPhyStat10BaseTxFD)) {
		printk(KERN_INFO "Full Duplex\n");
		ei_local->NicTransmitConfig |= TCR_FULL_DUPLEX;
	}
	else {
		printk(KERN_INFO "Half Duplex\n");
		ei_local->NicTransmitConfig &= ~TCR_FULL_DUPLEX;
	}
	return AX_TRUE;
}


static INT
AXGetPhyCapability(
    IN struct device *dev
    )
{
    struct ei_device *ei_local = (struct ei_device *) dev->priv;
	INT	fgMediaLinkFail;
	USHORT	uStatusReg;

//	if (!ei_local->fgReady)
//		return AX_FALSE;

	if (ei_local->fgWorkBusy)
	{
		ei_local->fgWorkBusy = AX_FALSE;
		return AX_FALSE;
	}

	MiiReadRegister(
		dev,
		ei_local->uPhyAddr,
		PhyStatusReg,
		&uStatusReg
		);

	MiiReadRegister(
		dev,
		ei_local->uPhyAddr,
		PhyStatusReg,
		&uStatusReg
		);

	if (uStatusReg & MiiPhyLinkStatus)
		fgMediaLinkFail = AX_FALSE;
	else
		fgMediaLinkFail = AX_TRUE;

	if (ei_local->fgMediaLinkFail != fgMediaLinkFail)
	{
		ei_local->fgMediaLinkFail = fgMediaLinkFail;
		if (fgMediaLinkFail)
		{
			// Since the MII make the auto-negotiation,
			// we don't need to re-configure the hardware
//			if (!ei_local->uConnectionType & MEDIA_AUTOSENSE)
			return AX_TRUE;
		}
	}

	if (ei_local->uForcedConnectionType != 0)
		return AX_FALSE;		// user take the responsibility.

	if (MediaModeChanged(dev))
	{
//		ODS("Operation Mode Changed !!\n");
		// ... ...
	}

	return AX_FALSE;
}

/* Mii functions end */


#ifdef MODULE

EXPORT_SYMBOL(ei_open);
EXPORT_SYMBOL(ei_close);
EXPORT_SYMBOL(ei_interrupt);
EXPORT_SYMBOL(ethdev_init);
EXPORT_SYMBOL(NS8390_init);

struct module *NS8390_module = NULL;

int init_module(void)
{
	NS8390_module = &__this_module;
	return 0;
}

void cleanup_module(void)
{
	NS8390_module = NULL;
}

#endif /* MODULE */

/*
 * Local variables:
 *  compile-command: "gcc -D__KERNEL__ -I/usr/src/linux/net/inet -Wall -Wstrict-prototypes -O6 -m486 -c 88790.c"
 *  version-control: t
 *  kept-new-versions: 5
 *  c-indent-level: 4
 *  tab-width: 4
 * End:
 */
